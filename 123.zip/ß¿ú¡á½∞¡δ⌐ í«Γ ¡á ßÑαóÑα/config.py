﻿BOT_TOKEN = "8084328163:AAGn1Fpxw3iYdQJdzS7S81H9QvmefabgabE"
CHANNEL_URL = "https://t.me/+9wlGG2NcCLc4ZTQ6"
CHANNEL_ID = "-1002558440780"
VERIF_CHANNEL_ID = "-1002558440780"
SUPP = "https://t.me/blancex"
ADMIN_ID = 6258371389
REF_LINK = "https://1wzyuh.com/v3/2158/1win-mines?p=xxv8"  # Добавлено
